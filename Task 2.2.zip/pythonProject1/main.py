# Import necessary libraries
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns

# Load the dataset
housing = pd.read_csv(r'E:\Internship\Week 2\Task 2.2\archive\housing.csv')

# Display the first few rows of the dataset
print("First few rows of the dataset:")
print(housing.head())

# Step 1: Data Cleaning
# Identify and handle missing data
print("\nMissing data before handling:")
print(housing.isnull().sum())

# For simplicity, let's drop rows with missing values
housing_cleaned = housing.dropna()

print("\nMissing data after handling:")
print(housing_cleaned.isnull().sum())


# Identify and handle outliers
# For this example, we will use the IQR method to detect outliers in numerical columns

def remove_outliers(df, column):
    Q1 = df[column].quantile(0.25)
    Q3 = df[column].quantile(0.75)
    IQR = Q3 - Q1
    lower_bound = Q1 - 1.5 * IQR
    upper_bound = Q3 + 1.5 * IQR
    return df[(df[column] >= lower_bound) & (df[column] <= upper_bound)]


# Apply the function to relevant numerical columns
numerical_columns = housing_cleaned.select_dtypes(include=[np.number]).columns

for col in numerical_columns:
    housing_cleaned = remove_outliers(housing_cleaned, col)

print("\nData after removing outliers:")
print(housing_cleaned.describe())

# Step 2: Data Transformation
# Create a new feature 'Rooms per Household'
housing_cleaned['Rooms per Household'] = housing_cleaned['total_rooms'] / housing_cleaned['households']

# Categorize the median house value into 'Low', 'Medium', and 'High'
housing_cleaned['House Value Category'] = pd.qcut(housing_cleaned['median_house_value'],
                                                  q=3,
                                                  labels=['Low', 'Medium', 'High'])

print("\nData with new features:")
print(housing_cleaned[['Rooms per Household', 'House Value Category']].head())

# Step 3: Data Visualization
# Plot a histogram of median house values
plt.figure(figsize=(10, 6))
sns.histplot(housing_cleaned['median_house_value'], bins=30, kde=True)
plt.title('Histogram of Median House Values')
plt.xlabel('Median House Value')
plt.ylabel('Frequency')
plt.show()

# Scatter plot to show the relationship between median income and median house value
plt.figure(figsize=(10, 6))
sns.scatterplot(data=housing_cleaned,
                x='median_income',
                y='median_house_value',
                hue='House Value Category',
                palette='viridis')
plt.title('Median Income vs. Median House Value')
plt.xlabel('Median Income')
plt.ylabel('Median House Value')
plt.legend(title='House Value Category')
plt.show()
